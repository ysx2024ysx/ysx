from pymongo import MongoClient

def get_db():
    uri = "mongodb://libWriter:123456@nosql01:27016/?authSource=admin"
    client = MongoClient(uri)
    return client, client["library"]
