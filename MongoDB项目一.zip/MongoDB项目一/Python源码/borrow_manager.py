def add_borrow_log(db, isbn, card):
    return db.borrow_logs.insert_one({"book_isbn": isbn, "reader_card": card, "status": "借出"})
