def get_category_stats(db):
    return list(db.books.aggregate([{"$group": {"_id": "$category", "count": {"$sum": 1}, "avgPrice": {"$avg": "$price"}}}]))
