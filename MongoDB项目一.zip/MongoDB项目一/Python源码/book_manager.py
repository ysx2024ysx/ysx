def search_books(db, query):
    return list(db.books.find(query, {"_id": 0, "title": 1, "author": 1, "price": 1}).limit(5))
