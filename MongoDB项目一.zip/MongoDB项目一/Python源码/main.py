import mongodb_connect
import book_manager
import reader_manager
import borrow_manager
import stat_manager

def show_menu():
    print("\n" + "="*30)
    print(" 图书情报检索与统计平台")
    print("="*30)
    print("1. 检索图书（按书名/类别）")
    print("2. 图书评分排行（前5）")
    print("3. 读者信息查询（总数与分布）")
    print("4. 借阅登记")
    print("5. 归还处理")
    print("6. 逾期查询")
    print("7. 分类统计报表")
    print("0. 退出系统")
    print("="*30)

def main():
    try:
        client, db = mongodb_connect.get_db()
        print("✅ 数据库连接成功！当前图书总数：", db.books.count_documents({}))
    except Exception as e:
        print("❌ 数据库连接失败，请检查：", e)
        return
        
    while True:
        show_menu()
        choice = input("请输入功能编号: ")
        
        if choice == '1':
            keyword = input("请输入书名关键字(直接回车查所有): ")
            query = {"title": {"$regex": keyword, "$options": "i"}} if keyword else {}
            results = book_manager.search_books(db, query)
            print(f"找到相关图书: {results}")
            
        elif choice == '2':
            pipeline = [{"$sort": {"rating": -1}}, {"$limit": 5}, {"$project": {"_id": 0, "title": 1, "rating": 1}}]
            results = list(db.books.aggregate(pipeline))
            print("评分前五图书：", results)
            
        elif choice == '3':
            total = db.readers.count_documents({})
            print(f"当前注册读者总数: {total} 人")
            stats = reader_manager.get_reader_stats(db)
            for doc in stats:
                print(f" - {doc['_id']}: {doc['count']}人")
                
        elif choice == '4':
            isbn = input("请输入图书ISBN: ")
            card = input("请输入读者证号: ")
            borrow_manager.add_borrow_log(db, isbn, card)
            print("借阅登记成功！")
            
        elif choice == '5':
            card = input("请输入读者证号: ")
            result = db.borrow_logs.update_many({"reader_card": card, "status": "借出"}, {"$set": {"status": "已归还"}})
            print(f"归还处理完成，影响记录数: {result.modified_count}")
            
        elif choice == '6':
            count = db.borrow_logs.count_documents({"status": "逾期"})
            print(f"当前逾期未还记录数: {count} 条")
            
        elif choice == '7':
            stats = stat_manager.get_category_stats(db)
            for doc in stats:
                print(f"类别: {doc['_id']}, 数量: {doc['count']}, 平均价: {doc['avgPrice']:.2f}元")
                
        elif choice == '0':
            print("退出系统，再见！")
            break
        else:
            print("输入无效，请重新输入！")
            
    client.close()

if __name__ == "__main__":
    main()
