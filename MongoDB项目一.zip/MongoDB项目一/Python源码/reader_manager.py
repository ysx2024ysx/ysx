def get_reader_stats(db):
    return list(db.readers.aggregate([{"$group": {"_id": "$college", "count": {"$sum": 1}}}]))
